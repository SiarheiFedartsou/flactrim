#ifndef <+FILE NAME ROOT+>_hpp
#define <+FILE NAME ROOT+>_hpp

#endif
